
Android ANR日志实战分析指南
一.概述

     ANR(Application Not responding)，是指应用程序未响应，Android系统对于一些事件需要在一定的时间范围内完成，如果超过预定时间能未能得到有效响应或者响应时间过长，都会造成ANR。一般地，这时往往会弹出一个提示框，告知用户当前xxx未响应，用户可选择继续等待或者Force Close。

    触发ANR的过程可分为三个步骤: 埋炸弹, 拆炸弹, 引爆炸弹。对于原理性的东西，我想大家也不是非常愿意花时间去看，如果有兴趣的可以参与大神Gityuan的博客，里面有非常详细的梳理，奉上链接http://gityuan.com/2016/07/02/android-anr/ 。

 

二.ANR的类型

InputDispatchTimeout（常见）
 input事件在5S内没有处理完成发生了ANR。

 logcat日志关键字：Input event dispatching timed out

BroadcastTimeout
前台Broadcast：onReceiver在10S内没有处理完成发生ANR。

后台Broadcast：onReceiver在60s内没有处理完成发生ANR。

logcat日志关键字：Timeout of broadcast BroadcastRecord

ServiceTimeout
前台Service：onCreate，onStart，onBind等生命周期在20s内没有处理完成发生ANR。

后台Service：onCreate，onStart，onBind等生命周期在200s内没有处理完成发生ANR

logcat日志关键字：Timeout executing service

ContentProviderTimeout
ContentProvider 在10S内没有处理完成发生ANR。

logcat日志关键字：timeout publishing content providers

 

 

三.ANR出现的原因

主线程频繁进行耗时的IO操作：如数据库读写
多线程操作的死锁，主线程被block；
主线程被Binder 对端block；
System Server中WatchDog出现ANR；
service binder的连接达到上线无法和和System Server通信
系统资源已耗尽（管道、CPU、IO）
 

四.ANR案例分析过程

    下面我将带领大家一步一步分析ANR，这个过程更加理解如何找到问题、分析问题以及解决问题

1.查看events log

    当发生ANR时可以从events log(当然前提是你有将events日志保存了下来)日志中搜索关键字:am_anr，找到出现ANR的时间点、进程PID、ANR类型。日志如下

10-26 09:36:52.873  4514  4622 I am_anr  : [0,11059,com.xxx.anrproject,950582854,Input dispatching timed out (Waiting to send non-key event because the touched window has not finished processing 
certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.)]
从上面的log我们可以看出： 应用com.xxx.anrproject在10-26 09:36:52.873时间，发生了一次InputDispatchTimeout类型的ANR，它的进程号是1480. 把关键的信息整理一下：
ANR时间：10-26 09:36:52.873
进程pid：11059

进程名：com.xxx.anrproject
ANR类型：InputDispatchTimeout

我们已经知道了发生InputDispatchTimeout的ANR是因为 input事件在5秒内没有处理完成。那么在这个时间10-26 09:36:52.873的前5秒，也就是（09:36:52 ~09:36:53）时间段左右程序到底做了什么事情？这个简单，因为我们已经知道pid了，再搜索一下pid = 11059的日志.这些日志表示该进程所运行的轨迹，关键的日志如下：

10-26 09:36:52.791  4514  4676 I InputDispatcher: Application is not responding: Window{85eac2d u0 com.xxx.anrproject/com.xxx.anrproject.MainActivity}.  It has been 5005.7ms since event, 5005.4ms since wait started.  Reason: Waiting to send non-key event because the touched window has not finished processing certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.
10-26 09:36:52.805  4514  4676 I WindowManager: Input event dispatching timed out sending to com.xxx.anrproject/com.xxx.anrproject.MainActivity.  Reason: Waiting to send non-key event because the touched window has not finished processing certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.
10-26 09:36:52.973  4514  4622 I Process : Sending signal. PID: 11059 SIG: 3
 
从上面我们可以知道，在时间 10-26 09:36:52.791程序发生了InputDispatcher: Application is not responding: Window{85eac2d u0 com.xxx.anrproject/com.xxx.anrproject.MainActivity}没有响应，5秒后发生了InputDispatchTimeout的ANR异常。

虽然知道了是怎么开始的，但是具体原因还没有找到，是不是当时CPU很紧张、各路APP再抢占资源？ 我们再看看CPU的信息,。搜索关键字关键字： ANR IN

10-26 09:36:52.791  4514  4676 I InputDispatcher: Application is not responding: Window{85eac2d u0 com.xxx.anrproject/com.xxx.anrproject.MainActivity}.  It has been 5005.7ms since event, 5005.4ms since wait started.  Reason: Waiting to send non-key event because the touched window has not finished processing certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.
10-26 09:36:52.805  4514  4676 I WindowManager: Input event dispatching timed out sending to com.xxx.anrproject/com.xxx.anrproject.MainActivity.  Reason: Waiting to send non-key event because the touched window has not finished processing certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.
10-26 09:36:52.973  4514  4622 I Process : Sending signal. PID: 11059 SIG: 3
10-26 09:36:52.974 11059 11065 I art     : Thread[3,tid=11065,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c2eee0,"Signal Catcher"]: reacting to signal 3
10-26 09:36:52.974 11059 11065 I art     :
10-26 09:36:53.124  4514  4622 I Process : Sending signal. PID: 4514 SIG: 3
10-26 09:36:53.125  4514  4522 I art     : Thread[2,tid=4522,WaitingInMainSignalCatcherLoop,Thread*=0xa1223800,peer=0x12c010d0,"Signal Catcher"]: reacting to signal 3
10-26 09:36:53.125  4514  4522 I art     :
10-26 09:36:53.131 11059 11065 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:53.149  4929  4929 D wpa_supplicant: wlan0: Control interface command 'SIGNAL_POLL'
10-26 09:36:53.163  4929  4929 D wpa_supplicant: CTRL-DEBUG: global_ctrl_sock-sendto: sock=8 sndbuf=163840 outq=0 send_len=48
10-26 09:36:53.411   584  4598 E NetlinkEvent: NetlinkEvent::FindParam(): Parameter 'UID' not found
10-26 09:36:53.716  4514  4926 E WifiHAL : Error polling socket
10-26 09:36:53.935  4514  4622 I Process : Sending signal. PID: 5875 SIG: 3
10-26 09:36:53.936  5875  5885 I art     : Thread[3,tid=5885,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c23310,"Signal Catcher"]: reacting to signal 3
10-26 09:36:53.936  5875  5885 I art     :
10-26 09:36:53.937  4514  4522 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.051  4514  4622 I Process : Sending signal. PID: 5862 SIG: 3
10-26 09:36:54.052  5862  5871 I art     : Thread[3,tid=5871,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c240d0,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.052  5875  5885 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.052  5862  5871 I art     :
10-26 09:36:54.180  4514  4622 I Process : Sending signal. PID: 5846 SIG: 3
10-26 09:36:54.180  5846  5854 I art     : Thread[3,tid=5854,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c20dc0,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.180  5862  5871 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.180  5846  5854 I art     :
10-26 09:36:54.307  4514  4622 I Process : Sending signal. PID: 5832 SIG: 3
10-26 09:36:54.307  5846  5854 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.308  5832  5840 I art     : Thread[3,tid=5840,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c20b80,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.308  5832  5840 I art     :
10-26 09:36:54.449  4514  4622 I Process : Sending signal. PID: 5797 SIG: 3
10-26 09:36:54.450  5797  5820 I art     : Thread[3,tid=5820,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c20940,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.450  5797  5820 I art     :
10-26 09:36:54.450  5832  5840 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.588  4514  4622 I Process : Sending signal. PID: 5176 SIG: 3
10-26 09:36:54.588  5797  5820 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.588  5176  5208 I art     : Thread[3,tid=5208,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c00f70,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.589  5176  5208 I art     :
10-26 09:36:54.861  4514  4622 I Process : Sending signal. PID: 5149 SIG: 3
10-26 09:36:54.862  5176  5208 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:54.862  5149  5171 I art     : Thread[3,tid=5171,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c00d30,"Signal Catcher"]: reacting to signal 3
10-26 09:36:54.862  5149  5171 I art     :
10-26 09:36:55.043  4514  4622 I Process : Sending signal. PID: 4966 SIG: 3
10-26 09:36:55.043  5149  5171 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:55.043  4966  4983 I art     : Thread[3,tid=4983,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c00af0,"Signal Catcher"]: reacting to signal 3
10-26 09:36:55.044  4966  4983 I art     :
10-26 09:36:55.154  4966  4983 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:55.155  4514  4622 I Process : Sending signal. PID: 4754 SIG: 3
10-26 09:36:55.155  4754  4766 I art     : Thread[3,tid=4766,WaitingInMainSignalCatcherLoop,Thread*=0xa1223d00,peer=0x12c00670,"Signal Catcher"]: reacting to signal 3
10-26 09:36:55.155  4754  4766 I art     :
10-26 09:36:55.378  4754  4766 I art     : Wrote stack traces to '/data/anr/traces.txt'
10-26 09:36:55.400   250   250 W         : debuggerd: handling request: pid=424 uid=1000 gid=1003 tid=424
10-26 09:36:55.569   250   250 W         : debuggerd: resuming target 424
10-26 09:36:55.571   250   250 W         : debuggerd: handling request: pid=561 uid=1041 gid=1005 tid=561
10-26 09:36:55.716   250   250 W         : debuggerd: resuming target 561
10-26 09:36:55.718   250   250 W         : debuggerd: handling request: pid=562 uid=1047 gid=1005 tid=562
10-26 09:36:55.765   250   250 W         : debuggerd: resuming target 562
10-26 09:36:55.768   250   250 W         : debuggerd: handling request: pid=569 uid=1019 gid=1019 tid=569
10-26 09:36:55.805   250   250 W         : debuggerd: resuming target 569
10-26 09:36:55.807   250   250 W         : debuggerd: handling request: pid=579 uid=1046 gid=1006 tid=579
10-26 09:36:55.863   250   250 W         : debuggerd: resuming target 579
10-26 09:36:55.866   250   250 W         : debuggerd: handling request: pid=580 uid=1013 gid=1031 tid=580
10-26 09:36:55.898   250   250 W         : debuggerd: resuming target 580
10-26 09:36:55.900   250   250 W         : debuggerd: handling request: pid=581 uid=1040 gid=1026 tid=581
10-26 09:36:55.955   250   250 W         : debuggerd: resuming target 581
10-26 09:36:55.957   250   250 W         : debuggerd: handling request: pid=582 uid=1013 gid=1005 tid=582
10-26 09:36:56.019   250   250 W         : debuggerd: resuming target 582
10-26 09:36:56.022   250   250 W         : debuggerd: handling request: pid=4760 uid=1023 gid=1023 tid=4760
10-26 09:36:56.054   250   250 W         : debuggerd: resuming target 4760
10-26 09:36:56.184  4929  4929 D wpa_supplicant: wlan0: Control interface command 'SIGNAL_POLL'
10-26 09:36:56.201  4929  4929 D wpa_supplicant: CTRL-DEBUG: global_ctrl_sock-sendto: sock=8 sndbuf=163840 outq=0 send_len=48
10-26 09:36:57.002  4514  4622 E ActivityManager: ANR in com.xxx.anrproject (com.xxx.anrproject/.MainActivity) (进程名)
10-26 09:36:57.002  4514  4622 E ActivityManager: PID: 11059  (进程PID)
10-26 09:36:57.002  4514  4622 E ActivityManager: Reason: Input dispatching timed out (Waiting to send non-key event because the touched window has not finished processing certain input events that were delivered to it over 500.0ms ago.  Wait queue length: 8.  Wait queue head age: 5950.0ms.)
10-26 09:36:57.002  4514  4622 E ActivityManager: Load: 4.21 / 3.79 / 4.33 (Load表明是1分钟,5分钟,15分钟CPU的负载)
10-26 09:36:57.002  4514  4622 E ActivityManager: CPU usage from 87287ms to 0ms ago (2019-10-26 09:35:25.543 to 2019-10-26 09:36:52.830):
10-26 09:36:57.002  4514  4622 E ActivityManager:   7.2% 4514/system_server: 3.5% user + 3.6% kernel / faults: 7651 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   2.5% 424/surfaceflinger: 0.9% user + 1.6% kernel / faults: 635 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   2.2% 4754/com.android.systemui: 1.4% user + 0.8% kernel / faults: 520 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   1.5% 525/xxxservice: 0.2% user + 1.2% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 4723/adbd: 0% user + 0% kernel / faults: 4879 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.5% 240/logd: 0.1% user + 0.3% kernel / faults: 25 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5922/com.android.launcher3: 0% user + 0% kernel / faults: 3958 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.4% 10890/kworker/0:1: 0% user + 0.4% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.3% 9123/kworker/u8:5: 0% user + 0.3% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.3% 10273/kworker/0:3: 0% user + 0.3% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.2% 4884/VosMCThread: 0% user + 0.2% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.2% 4929/wpa_supplicant: 0.1% user + 0% kernel / faults: 335 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 561/audioserver: 0% user + 0% kernel / faults: 37 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.2% 8916/kworker/u8:2: 0% user + 0.2% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.2% 34/kworker/u9:0: 0% user + 0.2% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 5832/com.xxxdroid.osmanager: 0.1% user + 0% kernel / faults: 425 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 168/mmcqd/0: 0% user + 0.1% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 200/kworker/1:4: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 10931/kworker/u8:1: 0% user + 0.1% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5724/core_ctl/0: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 6865/.client: 0% user + 0% kernel / faults: 958 minor 11 major
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 10041/kworker/3:3: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0.1% 10952/mdss_fb0: 0% user + 0.1% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 7/rcu_preempt: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 1024/lowi-server: 0% user + 0% kernel / faults: 102 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 4885/VosTXThread: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 3/ksoftirqd/0: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 672/xxx_logcat: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 492/ptt_socket_app: 0% user + 0% kernel / faults: 2036 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 548/xxxdroid_logservice: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 4886/VosRXThread: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 6746/com.android.defcontainer: 0% user + 0% kernel / faults: 392 minor 25 major
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 10/migration/0: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 11/migration/1: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 10947/kworker/u8:3: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 6/kworker/u8:0: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 15/migration/2: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 19/migration/3: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 64/system: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 104/kswapd0: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 160/cfinteractive: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 1026/xtwifi-client: 0% user + 0% kernel / faults: 26 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5726/irq/215-408000.: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5862/com.xxxdroid.verify: 0% user + 0% kernel / faults: 86 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 6723/kworker/2:3: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 1//init: 0% user + 0% kernel / faults: 3 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 16/ksoftirqd/2: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 135/hwrng: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 230/jbd2/mmcblk0p40: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 422/lmkd: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 423/servicemanager: 0% user + 0% kernel / faults: 52 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 524/zygote: 0% user + 0% kernel / faults: 150 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 570/installd: 0% user + 0% kernel / faults: 97 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5149/.dataservices: 0% user + 0% kernel / faults: 11 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5176/com.android.phone: 0% user + 0% kernel / faults: 28 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 5900/perfd: 0% user + 0% kernel / faults: 11 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 6788/org.codeaurora.gallery: 0% user + 0% kernel / faults: 146 minor 62 major
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 2/kthreadd: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 9/rcu_sched: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 12/ksoftirqd/1: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 20/ksoftirqd/3: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 22/kworker/3:0H: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 228/kworker/2:1H: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 489/cnd: 0% user + 0% kernel / faults: 7 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 509/thermal-engine: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 588/rild: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 593/cnss-daemon: 0% user + 0% kernel
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 594/loc_launcher: 0% user + 0% kernel / faults: 101 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 678/qmuxd: 0% user + 0% kernel / faults: 12 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 4760/sdcard: 0% user + 0% kernel / faults: 6 minor
10-26 09:36:57.002  4514  4622 E ActivityManager:   0% 4869/VosWDThrea

我已经在log 中标志了相关的含义。com.xxx.anrproject 占用了极少数的CPU，完全没有体现出来，其实这并不算多。现在的手机基本都是多核CPU。假如你的CPU是4核，那么上限是400%，以此类推。

既然不是CPU负载的原因，那么到底是什么原因呢？ 这时就要看我们的终极大杀器——traces.txt。

 

2.traces.txt 日志分析

    当APP不响应、响应慢了、或者WatchDog的监视没有得到回应时，系统就会dump出一个traces.txt文件，存放在文件目录:/data/anr/traces.txt，通过traces文件,我们可以拿到线程名、堆栈信息、线程当前状态、binder call等信息。
通过adb命令拿到该文件：adb pull /data/anr/traces.txt
trace: Cmd line:com.xxx.anrproject

 

​
"main" prio=5 tid=1 Sleeping
  | group="main" sCount=1 dsCount=0 obj=0x7392e730 self=0xacf84400
  | sysTid=11059 nice=-10 cgrp=default sched=0/0 handle=0xb047752c
  | state=S schedstat=( 310040005 80960887 319 ) utm=20 stm=11 core=0 HZ=100
  | stack=0xbe61f000-0xbe621000 stackSize=8MB
  | held mutexes=
  at java.lang.Thread.sleep!(Native method)
  - sleeping on <0x0eaa6bed> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:371)
  - locked <0x0eaa6bed> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:313)
  at com.xxx.anrproject.MainActivity.FUN1(MainActivity.java:33)
  at com.xxx.anrproject.MainActivity.access$0(MainActivity.java:30)
  at com.xxx.anrproject.MainActivity$1.onClick(MainActivity.java:24)
  at android.view.View.performClick(View.java:5637)
  at android.view.View$PerformClick.run(View.java:22433)
  at android.os.Handler.handleCallback(Handler.java:751)
  at android.os.Handler.dispatchMessage(Handler.java:95)
  at android.os.Looper.loop(Looper.java:154)
  at android.app.ActivityThread.main(ActivityThread.java:6121)
  at java.lang.reflect.Method.invoke!(Native method)
  at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:889)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:779)
 
​
我详细解析一下traces.txt里面的一些字段，看看它到底能给我们提供什么信息.
main：main标识是主线程，如果是线程，那么命名成“Thread-X”的格式,x表示线程id,逐步递增。
prio：线程优先级,默认是5
tid：tid不是线程的id，是线程唯一标识ID
group：是线程组名称
sCount：该线程被挂起的次数
dsCount：是线程被调试器挂起的次数
obj：对象地址
self：该线程Native的地址
sysTid：是线程号(主线程的线程号和进程号相同)
nice：是线程的调度优先级
sched：分别标志了线程的调度策略和优先级
cgrp：调度归属组
handle：线程处理函数的地址。
state：是调度状态
schedstat：从 /proc/[pid]/task/[tid]/schedstat读出，三个值分别表示线程在cpu上执行的时间、线程的等待时间和线程执行的时间片长度，不支持这项信息的三个值都是0；
utm：是线程用户态下使用的时间值(单位是jiffies）
stm：是内核态下的调度时间值
core：是最后执行这个线程的cpu核的序号。

Java的堆栈信息是我们最关心的，它能够定位到具体位置。从上面的traces,我们可以判断at com.xxx.anrproject.MainActivity.FUN1(MainActivity.java:33) 导致了com.xxx.anrproject发生了ANR。这时候可以对着源码查看，找到出问题，并且解决它。

总结一下这分析流程：首先我们搜索am_anr，找到出现ANR的时间点、进程PID、ANR类型、然后再找搜索PID，找前5秒左右的日志。过滤ANR IN 查看CPU信息，接着查看traces.txt，找到java的堆栈信息定位代码位置，最后查看源码，分析与解决问题。这个过程基本能找到发生ANR的来龙去脉。

 

五.ANR案例分析

1.主线程被其它线程lock，导致死锁

waiting on <0x1cd570> (a android.os.MessageQueue)

DALVIK THREADS:
"main" prio=5 tid=3 TIMED_WAIT
  | group="main" sCount=1 dsCount=0 s=0 obj=0x400143a8
  | sysTid=691 nice=0 sched=0/0 handle=-1091117924
  at java.lang.Object.wait(Native Method)
  - waiting on <0x1cd570> (a android.os.MessageQueue)
  at java.lang.Object.wait(Object.java:195)
  at android.os.MessageQueue.next(MessageQueue.java:144)
  at android.os.Looper.loop(Looper.java:110)
  at android.app.ActivityThread.main(ActivityThread.java:3742)
  at java.lang.reflect.Method.invokeNative(Native Method)
  at java.lang.reflect.Method.invoke(Method.java:515)
  at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:739)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:497)
  at dalvik.system.NativeStart.main(Native Method)
 
"Binder Thread #3" prio=5 tid=15 NATIVE
  | group="main" sCount=1 dsCount=0 s=0 obj=0x434e7758
  | sysTid=734 nice=0 sched=0/0 handle=1733632
  at dalvik.system.NativeStart.run(Native Method)
 
"Binder Thread #2" prio=5 tid=13 NATIVE
  | group="main" sCount=1 dsCount=0 s=0 obj=0x1cd570
  | sysTid=696 nice=0 sched=0/0 handle=1369840
  at dalvik.system.NativeStart.run(Native Method)
 
"Binder Thread #1" prio=5 tid=11 NATIVE
  | group="main" sCount=1 dsCount=0 s=0 obj=0x433aca10
  | sysTid=695 nice=0 sched=0/0 handle=1367448
  at dalvik.system.NativeStart.run(Native Method)
 
----- end 691 -----

2.主线程做耗时的操作：比如数据库读写

"main" prio=5 tid=1 Native
held mutexes=
kernel: (couldn't read /proc/self/task/11003/stack)
native: #00 pc 000492a4 /system/lib/libc.so (nanosleep+12)
native: #01 pc 0002dc21 /system/lib/libc.so (usleep+52)
native: #02 pc 00009cab /system/lib/libsqlite.so (???)
native: #03 pc 00011119 /system/lib/libsqlite.so (???)
native: #04 pc 00016455 /system/lib/libsqlite.so (???)
native: #16 pc 0000fa29 /system/lib/libsqlite.so (???)
native: #17 pc 0000fad7 /system/lib/libsqlite.so (sqlite3_prepare16_v2+14)
native: #18 pc 0007f671 /system/lib/libandroid_runtime.so (???)
native: #19 pc 002b4721 /system/framework/arm/boot-framework.oat (Java_android_database_sqlite_SQLiteConnection_nativePrepareStatement__JLjava_lang_String_2+116)
at android.database.sqlite.SQLiteConnection.setWalModeFromConfiguration(SQLiteConnection.java:294)
at android.database.sqlite.SQLiteConnection.open(SQLiteConnection.java:215)
at android.database.sqlite.SQLiteConnection.open(SQLiteConnection.java:193)
at android.database.sqlite.SQLiteConnectionPool.openConnectionLocked(SQLiteConnectionPool.java:463)
at android.database.sqlite.SQLiteConnectionPool.open(SQLiteConnectionPool.java:185)
at android.database.sqlite.SQLiteConnectionPool.open(SQLiteConnectionPool.java:177)
at android.database.sqlite.SQLiteDatabase.openInner(SQLiteDatabase.java:808)
locked <0x0db193bf> (a java.lang.Object)
at android.database.sqlite.SQLiteDatabase.open(SQLiteDatabase.java:793)
at android.database.sqlite.SQLiteDatabase.openDatabase(SQLiteDatabase.java:696)
at android.app.ContextImpl.openOrCreateDatabase(ContextImpl.java:690)
at android.content.ContextWrapper.openOrCreateDatabase(ContextWrapper.java:299)
at android.database.sqlite.SQLiteOpenHelper.getDatabaseLocked(SQLiteOpenHelper.java:223)
at android.database.sqlite.SQLiteOpenHelper.getWritableDatabase(SQLiteOpenHelper.java:163)
locked <0x045a4a8c> (a com.xxxx.video.common.data.DataBaseHelper)
at com.xxxx.video.common.data.DataBaseORM.<init>(DataBaseORM.java:46)
at com.xxxx.video.common.data.DataBaseORM.getInstance(DataBaseORM.java:53)
locked <0x017095d5> (a java.lang.Class<com.xxxx.video.common.data.DataBaseORM>)

 

3.BroadcastTimeout，广播里面做耗时操作

"main" prio=5 tid=1 Sleeping
  | group="main" sCount=1 dsCount=0 obj=0x7392e730 self=0xacf84400
  | sysTid=12158 nice=-10 cgrp=default sched=0/0 handle=0xb047752c
  | state=S schedstat=( 278856989 47585413 287 ) utm=17 stm=10 core=2 HZ=100
  | stack=0xbe61f000-0xbe621000 stackSize=8MB
  | held mutexes=
  at java.lang.Thread.sleep!(Native method)
  - sleeping on <0x0eaa6bed> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:371)
  - locked <0x0eaa6bed> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:313)
  at com.xxx.anrproject.ANRBroadCast.FUN1(ANRBroadCast.java:17)
  at com.xxx.anrproject.ANRBroadCast.onReceive(ANRBroadCast.java:12)
  at android.app.ActivityThread.handleReceiver(ActivityThread.java:3041)
  at android.app.ActivityThread.-wrap18(ActivityThread.java:-1)
  at android.app.ActivityThread$H.handleMessage(ActivityThread.java:1562)
  at android.os.Handler.dispatchMessage(Handler.java:102)
  at android.os.Looper.loop(Looper.java:154)
  at android.app.ActivityThread.main(ActivityThread.java:6121)
  at java.lang.reflect.Method.invoke!(Native method)
  at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:889)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:779)

4.System Server中WatchDog出现ANR

    如果出现这种情况的ANR，这种一般在日志里面查找held by关键词。本案例可以见附件的文件，里面更加详细。

"Binder:1441_1D" prio=5 tid=122 Blocked
  | group="main" sCount=1 dsCount=0 obj=0x13f84e50 self=0x87a42900
  | sysTid=7317 nice=-2 cgrp=default sched=0/0 handle=0x849f6920
  | state=S schedstat=( 523254409041 294353783250 2408164 ) utm=38176 stm=14149 core=3 HZ=100
  | stack=0x848fa000-0x848fc000 stackSize=1014KB
  | held mutexes=
  at com.android.server.power.PowerManagerService.setScreenBrightnessOverrideFromWindowManagerInternal(PowerManagerService.java:2777)
  - waiting to lock <0x0af04ad6> (a java.lang.Object) held by thread 20
  at com.android.server.power.PowerManagerService.-wrap28(PowerManagerService.java:-1)
  at com.android.server.power.PowerManagerService$LocalService.setScreenBrightnessOverrideFromWindowManager(PowerManagerService.java:3879)
  at com.android.server.wm.WindowSurfacePlacer.performSurfacePlacementInner(WindowSurfacePlacer.java:492)
  at com.android.server.wm.WindowSurfacePlacer.performSurfacePlacementLoop(WindowSurfacePlacer.java:236)
  at com.android.server.wm.WindowSurfacePlacer.performSurfacePlacement(WindowSurfacePlacer.java:184)
  at com.android.server.wm.WindowManagerService.moveStackWindowsLocked(WindowManagerService.java:5067)
  at com.android.server.wm.WindowManagerService.moveTaskToTop(WindowManagerService.java:5096)
  - locked <0x0c05deae> (a java.util.HashMap)
  at com.android.server.am.ActivityStack.moveToFront(ActivityStack.java:729)
  at com.android.server.am.ActivityStackSupervisor.moveActivityStackToFront(ActivityStackSupervisor.java:1615)
  at com.android.server.am.ActivityManagerService.setFocusedActivityLocked(ActivityManagerService.java:3105)
  at com.android.server.am.ActivityStack.adjustFocusedActivityLocked(ActivityStack.java:3267)
  at com.android.server.am.ActivityStack.finishActivityLocked(ActivityStack.java:3540)
  at com.android.server.am.ActivityStack.requestFinishActivityLocked(ActivityStack.java:3364)
  at com.android.server.am.ActivityManagerService.finishActivity(ActivityManagerService.java:5023)
  - locked <0x00ed044f> (a com.android.server.am.ActivityManagerService)
  at android.app.ActivityManagerNative.onTransact(ActivityManagerNative.java:382)
  at com.android.server.am.ActivityManagerService.onTransact(ActivityManagerService.java:2859)
  at android.os.Binder.execTransact(Binder.java:565)
 
"ActivityManager" prio=5 tid=11 Blocked
  | group="main" sCount=1 dsCount=0 obj=0x12c1aec0 self=0xa8f05800
  | sysTid=1480 nice=-2 cgrp=default sched=0/0 handle=0xa1879920
  | state=S schedstat=( 554591757112 206716799738 965453 ) utm=25815 stm=29644 core=1 HZ=100
  | stack=0xa1777000-0xa1779000 stackSize=1038KB
  | held mutexes=
  at com.android.server.am.ActivityManagerService$MainHandler.handleMessage(ActivityManagerService.java:1986)
  - waiting to lock <0x00ed044f> (a com.android.server.am.ActivityManagerService) held by thread 122
  at android.os.Handler.dispatchMessage(Handler.java:102)
  at android.os.Looper.loop(Looper.java:154)
  at android.os.HandlerThread.run(HandlerThread.java:61)
  at com.android.server.ServiceThread.run(ServiceThread.java:46)

    从日志可以看出7317 进程持有锁0x0af04ad6，然后其它进程在等待进程7317释放然后导致的死锁ANR错误

 

总结

     如上的文章借鉴了博客https://juejin.im/post/5be698d4e51d452acb74ea4c的一些信息，并加上了一些实际开发中遇到的ANR问题，希望可以给各位遇到ANR问题的解决提供一定的思路。如果大家想要更加一步的了解，那么强烈推荐Gityuan的博客，虽然人家已经远离Android步入了Fluter的海洋。

     最后老规矩，奉上全部ANR日志的汇总ANR各种日志大汇总
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。
                        
原文链接：https://blog.csdn.net/tkwxty/article/details/102753227
    
    


### 1. 理解ANR原理
参考文章 https://gityuan.com/2016/07/02/android-anr/

由于耗时操作导致ANR，因此很多开发者以为ANR问题都是应用层的问题，但实际上，线上环境捕获的大部分ANR由系统原因导致。

干货：ANR日志分析全面解析
2021-06-08
19,577
阅读13分钟

一、概述
解决ANR一直是Android 开发者需要掌握的重要技巧，一般从三个方面着手。

开发阶段：通过工具检查各个方法的耗时，卡顿情况，发现一处修改一处。

线上阶段：这个阶段主要依靠监控工具发现ANR并上报，比如matrix。

分析阶段：如果线上用户发生ANR，并且你获取了一份日志，这就涉及了本文要分享的内容——ANR日志分析技巧。

二、ANR产生机制
网上通俗的一段面试答题

ANR——应用无响应，Activity是5秒，BroadCastReceiver是10秒，Service是20秒。

这句话说的很笼统，要想深入分析定位ANR，需要知道更多知识点，一般来说，ANR按产生机制，分为4类：

2.1 输入事件超时(5s)
InputEvent Timeout

a.InputDispatcher发送key事件给 对应的进程的 Focused Window ，对应的window不存在、处于暂停态、或通道(input channel)占满、通道未注册、通道异常、或5s内没有处理完一个事件，就会发生ANR
​
b.InputDispatcher发送MotionEvent事件有个例外之处：当对应Touched Window的 input waitQueue中有超过0.5s的事件，inputDispatcher会暂停该事件，并等待5s，如果仍旧没有收到window的‘finish’事件，则触发ANR
​
c.下一个事件到达，发现有一个超时事件才会触发ANR
2.2 广播类型超时（前台15s，后台60s）
BroadcastReceiver Timeout

a.静态注册的广播和有序广播会ANR，动态注册的非有序广播并不会ANR
​
b.广播发送时，会判断该进程是否存在，不存在则创建，创建进程的耗时也算在超时时间里
​
c.只有当进程存在前台显示的Activity才会弹出ANR对话框，否则会直接杀掉当前进程
​
d.当onReceive执行超过阈值（前台15s，后台60s），将产生ANR
​
e.如何发送前台广播：Intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
2.3 服务超时（前台20s，后台200s）
Service Timeout

a.Service的以下方法都会触发ANR：onCreate(),onStartCommand(), onStart(), onBind(), onRebind(), onTaskRemoved(), onUnbind(),
onDestroy().
​
b.前台Service超时时间为20s，后台Service超时时间为200s
​
c.如何区分前台、后台执行————当前APP处于用户态，此时执行的Service则为前台执行。
​
d.用户态：有前台activity、有前台广播在执行、有foreground service执行
2.4 ContentProvider 类型
a.ContentProvider创建发布超时并不会ANR
​
b.使用ContentProviderclient来访问ContentProverder可以自主选择触发ANR，超时时间自己定
client.setDetectNotResponding(PROVIDER_ANR_TIMEOUT);
ps：Activity生命周期超时会不会ANR？——经测试并不会。

override fun onCreate(savedInstanceState: Bundle?) {
       Thread.sleep(60000)
       super.onCreate(savedInstanceState)
       setContentView(R.layout.activity_main)
   }
三

#### 2. 应用层导致的ANR（耗时操作）
##### 2.1 函数阻塞
在主线程执行的函数过慢导致ANR，函数阻塞又分为可预期和不可预期两类；
###### 2.1.1 可预期阻塞
**原因：** 在主线程执行的函数响应过慢，如IO操作、大数据处理等。这种慢函数处理起来是较为简单的，可预期解决的。

*除此之外的其他ANR问题定位和解决开始变得困难。/(ㄒoㄒ)/~~*

**排查办法：**
- 使用APM工具定位慢函数，如Matrix工具；
- 开启严苛模式，解决不当的主线程操作；

**解决办法：**
耗时操作转子线程处理。

##### 2.1.2 不可预期阻塞
**原因：** 非预期的代码逻辑错误导致的阻塞，如死循环、死锁、资源竞争(如锁竞争：与死锁不是同一原因)等；

死循环和死锁属于逻辑错误；死循环通常容易感知，死锁问题通过ANR日志可定位，资源竞争往往更复杂，情况也多样。

**排查办法：**
- 使用APM工具定位慢函数，如Matrix工具，可定位出因为得不到资源导致耗时过长的情况；
- ANR日志分析；

**解决办法：**
- 死循环属逻辑错误，DEBUG阶段通常可解；
- 日志分析
#### 3. 系统导致的ANR
**原因：** 
- CPU被抢占
- 系统服务无法及时响应：系统的服务都是Binder机制，服务能力也是有限的，有可能系统服务长时间不响应导致ANR
- 内存空间不足

CPU和内存资源不足在低端设备上感知较为明显；在应用层线程、内存使用得当的情况下此类问题应用层也束手无策，但可尽量将IPC操作、耗时操作等放入子线程，减少应用触发ANR给用户带来的不良体验。

  
#### 4. ANR日志分析
由于ANR的问题跟系统紧密相关，因此ANR日志分析时了解系统状态对问题的分析尤其重要，通常来说，如果系统状态良好发生ANR，那多半是应用层的问题，而系统负载过重的情况，极有可能是受系统影响导致ANR。
ANR日志中通常包含CPU负载、线程等相关的信息；


##### 4.1 CPU负载
```
CPU usage from 82268ms to -2ms ago (2025-05-24 23:04:45.447 to 2025-05-24 23:06:07.717):
  91% 2061/system_server: 61% user + 29% kernel / faults: 234705 minor 3172 major
  31% 1297/surfaceflinger: 18% user + 13% kernel / faults: 3449 minor 93 major
  10% 1204/android.hardware.graphics.composer@3.3-service: 4.2% user + 6.3% kernel / faults: 937 minor 16 major
  9.2% 516/logd: 2.8% user + 6.4% kernel / faults: 18859 minor 29 major
  6.8% 79/kswapd0: 0% user + 6.8% kernel
  0.5% 1507/media.extractor: 0.1% user + 0.3% kernel / faults: 209 minor 56 major
  0.6% 1747/kworker/u16:5-events_unbound: 0% user + 0.6% kernel
  0.5% 522/lmkd: 0.1% user + 0.3% kernel / faults: 12 minor
  ...中间省略N行...
 +0% 4938/com.android.managedprovisioning: 0% user + 0% kernel
 +0% 4961/com.android.printspooler: 0% user + 0% kernel
 +0% 5048/com.google.android.tts: 0% user + 0% kernel
 +0% 5136/com.google.android.apps.messaging: 0% user + 0% kernel
 +0% 5306/com.android.providers.calendar: 0% user + 0% kernel
 +0% 5367/com.google.android.googlequicksearchbox:search: 0% user + 0% kernel
 +0% 5411/artd: 0% user + 0% kernel
 +0% 5416/com.android.chrome: 0% user + 0% kernel
 +0% 5580/com.google.android.apps.googleassistant:remote: 0% user + 0% kernel
88% TOTAL: 36% user + 30% kernel + 17% iowait + 3.5% irq + 0.5% softirq
```

日志解释：

第一行：表示后面的内容是2025-05-24 23:04:45.447 到 2025-05-24 23:06:07.717时间段内各个进程的CPU使用率。

第二行 - 倒数第二行：**每一行都代表一个进程的CPU使用情况，格式如下：**

**<CPU使用率>% <进程ID>/<进程名>: <用户空间CPU使用率>% user + <内核空间CPU使用率>% kernel / faults: <minor faults数量> minor <major faults数量> major**

例如，第二行：

91% 2061/system_server: 61% user + 29% kernel / faults: 234705 minor 3172 major

表示system_server进程（进程ID为2061）的CPU使用率为91%，其中用户空间的CPU使用率为61%，内核空间的CPU使用率为29%。此外，这个进程产生了234705个minor faults和3172个major faults。

**用户空间和内核空间的CPU使用率之和可能不等于总的CPU使用率，这是因为还有其他因素（如I/O等待时间）会占用CPU时间。**

**faults**
**minor faults**
**major faults**

最后一行：各个进程合计占用的CPU信息。

名词解释：
```
user:用户态,kernel:内核态
faults:指的是页错误，当进程访问的内存页不在物理内存中时，就会发生页错误。
minor——轻微的，指的是可以不通过磁盘I/O就能解决的页错误.
major——重度的，指的是需要通过磁盘I/O才能解决的页错误。
iowait:IO使用（等待）占比
irq:硬中断，softirq:软中断

```
**iowait占比很高，意味着有很大可能，是io耗时导致ANR，具体进一步查看有没有进程faults major比较多。**

**单进程CPU的负载并不是以100%为上限，而是有几个核，就有百分之几百，如4核上限为400%。**

## 4.2 内存信息

```
Total number of allocations xxxx　　进程创建到现在一共创建了多少对象
Total bytes allocated xxxx　进程创建到现在一共申请了多少内存
Total bytes freed xxxx　　　进程创建到现在一共释放了多少内存
Free memory xxxx　　　 不扩展堆的情况下可用的内存
Free memory until GC xxxx　　GC前的可用内存
Free memory until OOME xxxx　　OOM之前的可用内存
Total memory 当前总内存（已用+可用）
Max memory xxxx  进程最多能申请的内存
```
**Free memory until OOME **的值很小的时候，表示应用已经处于内存紧张状态。**

除了trace文件中有内存信息，普通的eventlog日志中，也有内存信息（不一定打印）
```
am_meminfo: [350937088,41086976,492830720,427937792,291887104]
```
以上几个值分别指的是：

-   Cached
-   Free,
-   Zram,
-   Kernel,Native

Cached+Free的内存代表着当前整个手机的可用内存，如果值很小，意味着处于内存紧张状态。一般低内存的判定阈值为：4G 内存手机以下阀值：350MB，以上阀值则为：450MB

**Tips: 如果ANR时间点前后，日志里有打印onTrimMemory，也可以作为内存紧张的一个参考判断**

## 4.3 堆栈信息
日志中的堆栈信息展示了ANR发生的进程当前所有线程的信息和状态。
```
suspend all histogram:	Sum: 7.295ms 99% C.I. 6us-6780.800us Avg: 663.181us Max: 7055us
DALVIK THREADS (12):
"main" prio=5 tid=1 Native
  | group="main" sCount=0 ucsCount=0 flags=0 obj=0x7405ccd8 self=0xb400007530cc4be0
  | sysTid=5234 nice=0 cgrp=foreground sched=0/0 handle=0x779afe9d20
  | state=R schedstat=( 407591907 1247807921 682 ) utm=6 stm=34 core=5 HZ=100
  | stack=0x7ffe030000-0x7ffe032000 stackSize=8188KB
  | held mutexes= "mutator lock"(shared held)
  at kotlin.enums.a.a(unavailable:5)
  at kotlin.LazyThreadSafetyMode.<clinit>(unavailable:36)
  at xxx.xxx.xx.<clinit>(unavailable:8)
  at xxx.xxx.xx.onCreate(unavailable:101)
  at android.app.Instrumentation.callApplicationOnCreate(Instrumentation.java:1390)
  at android.app.ActivityThread.handleBindApplication(ActivityThread.java:7851)
  at android.app.ActivityThread.-$$Nest$mhandleBindApplication(unavailable:0)
  at android.app.ActivityThread$H.handleMessage(ActivityThread.java:2566)
  at android.os.Handler.dispatchMessage(Handler.java:107)
  at android.os.Looper.loopOnce(Looper.java:311)
  at android.os.Looper.loop(Looper.java:408)
  at android.app.ActivityThread.main(ActivityThread.java:9105)
  at java.lang.reflect.Method.invoke(Native method)
  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:627)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:970)
DumpLatencyMs: 138.687

"ReferenceQueueDaemon" daemon prio=5 tid=5 Waiting
  | group="system" sCount=1 ucsCount=0 flags=1 obj=0x1408bc60 self=0xb400007530ccf2c0
  | sysTid=5240 nice=4 cgrp=foreground sched=0/0 handle=0x74a4a01730
  | state=S schedstat=( 774384 0 1 ) utm=0 stm=0 core=2 HZ=100
  | stack=0x74a48fe000-0x74a4900000 stackSize=1037KB
  | held mutexes=
  at java.lang.Object.wait(Native method)
  - waiting on <0x06d653db> (a java.lang.Class<java.lang.ref.ReferenceQueue>)
  at java.lang.Object.wait(Object.java:405)
  at java.lang.Object.wait(Object.java:543)
  at java.lang.Daemons$ReferenceQueueDaemon.runInternal(Daemons.java:251)
  - locked <0x06d653db> (a java.lang.Class<java.lang.ref.ReferenceQueue>)
  at java.lang.Daemons$Daemon.run(Daemons.java:131)
  at java.lang.Thread.run(Thread.java:1012)
DumpLatencyMs: 248.356
```
上述日志只列出了两个进程的信息；

"suspend all histogram: Sum: 7.295ms 99% C.I. 6us-6780.800us Avg: 663.181us Max: 7055us" 这一行表示所有线程的暂停时间统计。Sum是所有线程的暂停时间总和，99% C.I. 是99%的线程暂停时间在6微秒到6780.8微秒之间，Avg是平均暂停时间，Max是最长的暂停时间。

"DALVIK THREADS (12):" 这一行表示设备上有12个Dalvik线程正在运行。Dalvik是Android系统的Java虚拟机，它负责执行Android应用的Java代码。

"main" prio=5 tid=1 Runnable 这一行表示主线程的状态。"main"是线程的名字，prio=5表示线程的优先级，tid=1表示线程的ID，Runnable表示线程的状态，Runnable状态意味着线程正在运行或者在运行队列中等待运行。

Java中线程有6种状态，定义在`java.lang.Thread.State`枚举中；
### Java线程状态

在Java中，线程可以通过`Thread`类或者`Executor`框架（如`ExecutorService`）来管理。Java线程有6种不同的状态(在`java.lang.Thread.State`中可查看具体定义)：

**NEW**：线程被创建但尚未启动。

**RUNNABLE**：线程正在Java虚拟机中执行，但它可能正在等待操作系统来提供资源。

**BLOCKED**：线程被阻塞并等待监视器锁，例如在调用`Object.wait()`、`Object.join()`或进入同步块时。

**WAITING**：线程处于等待状态，例如调用了`Object.wait()`但没有超时或未被通知/中断。

**TIMED_WAITING**：线程在等待一段指定的时间，例如调用`Thread.sleep(long millis)`或`Object.wait(long timeout)`。

**TERMINATED**：线程已完成执行。


原始的trace文件中的状态是CPP代码中定义的状态，因此跟Java线程之间存在对应关系：

**main线程处于 BLOCK、WAITING、TIMEWAITING状态，那基本上是函数阻塞导致ANR；如果main线程无异常，则应该排查CPU负载和内存环境。**

## 5 典型案例分析
### 5.1 主线程无卡顿，处于正常堆栈
```
"main" prio=5 tid=1 Native
  | group="main" sCount=1 dsCount=0 flags=1 obj=0x74b38080 self=0x7ad9014c00
  | sysTid=23081 nice=0 cgrp=default sched=0/0 handle=0x7b5fdc5548
  | state=S schedstat=( 284838633 166738594 505 ) utm=21 stm=7 core=1 HZ=100
  | stack=0x7fc95da000-0x7fc95dc000 stackSize=8MB
  | held mutexes=
  kernel: __switch_to+0xb0/0xbc
  kernel: SyS_epoll_wait+0x288/0x364
  kernel: SyS_epoll_pwait+0xb0/0x124
  kernel: cpu_switch_to+0x38c/0x2258
  native: #00 pc 000000000007cd8c  /system/lib64/libc.so (__epoll_pwait+8)
  native: #01 pc 0000000000014d48  /system/lib64/libutils.so (android::Looper::pollInner(int)+148)
  native: #02 pc 0000000000014c18  /system/lib64/libutils.so (android::Looper::pollOnce(int, int*, int*, void**)+60)
  native: #03 pc 00000000001275f4  /system/lib64/libandroid_runtime.so (android::android_os_MessageQueue_nativePollOnce(_JNIEnv*, _jobject*, long, int)+44)
  at android.os.MessageQueue.nativePollOnce(Native method)
  at android.os.MessageQueue.next(MessageQueue.java:330)
  at android.os.Looper.loop(Looper.java:169)
  at android.app.ActivityThread.main(ActivityThread.java:7073)
  at java.lang.reflect.Method.invoke(Native method)
  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:536)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:876)

```
Native状态、epool等关键字表明主线程正在等待新的消息（表示主线程没有在干活），如果ANR日志是这样一个状态，那说明抓取ANR日志的时候，主线程已经恢复正常，那该ANR可能是CPU抢占或内存紧张等系统因素引起，也可能是应用自身函数阻塞导致。分析系统负载情况进一步确认是否是负载过高导致；

### 5.2 主线程执行耗时操作

```
"main" prio=5 tid=1 Runnable
  | group="main" sCount=0 dsCount=0 flags=0 obj=0x72deb848 self=0x7748c10800
  | sysTid=8968 nice=-10 cgrp=default sched=0/0 handle=0x77cfa75ed0
  | state=R schedstat=( 24783612979 48520902 756 ) utm=2473 stm=5 core=5 HZ=100
  | stack=0x7fce68b000-0x7fce68d000 stackSize=8192KB
  | held mutexes= "mutator lock"(shared held)
  at xxxx.xx.$onCreate$2.onClick(MainActivity.kt:20)——关键行！！！
  at android.view.View.performClick(View.java:7187)
  at android.view.View.performClickInternal(View.java:7164)
  at android.view.View.access$3500(View.java:813)
  at android.view.View$PerformClick.run(View.java:27640)
  at android.os.Handler.handleCallback(Handler.java:883)
  at android.os.Handler.dispatchMessage(Handler.java:100)
  at android.os.Looper.loop(Looper.java:230)
  at android.app.ActivityThread.main(ActivityThread.java:7725)
  at java.lang.reflect.Method.invoke(Native method)
  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:526)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1034)

```
上述日志表明当前主线程处于正在执行状态，可以推测，可能的原因是在onClick事件处理函数中进行了一些耗时的操作，如网络请求、大量计算或者I/O操作等，这些操作阻塞了主线程，导致应用无法及时响应用户的操作，从而触发了ANR。

### 5.3 主线程被锁阻塞

```
"main" prio=5 tid=1 Blocked
  | group="main" sCount=1 dsCount=0 flags=1 obj=0x72deb848 self=0x7748c10800
  | sysTid=22838 nice=-10 cgrp=default sched=0/0 handle=0x77cfa75ed0
  | state=S schedstat=( 390366023 28399376 279 ) utm=34 stm=5 core=1 HZ=100
  | stack=0x7fce68b000-0x7fce68d000 stackSize=8192KB
  | held mutexes=
  at xxx.xx$onCreate$1.onClick(MainActivity.kt:15)
  - waiting to lock <0x01aed1da> (a java.lang.Object) held by thread 3 ——————关键行！！！
  at android.view.View.performClick(View.java:7187)
  at android.view.View.performClickInternal(View.java:7164)
  at android.view.View.access$3500(View.java:813)
  at android.view.View$PerformClick.run(View.java:27640)
  at android.os.Handler.handleCallback(Handler.java:883)
  at android.os.Handler.dispatchMessage(Handler.java:100)
  at android.os.Looper.loop(Looper.java:230)
  at android.app.ActivityThread.main(ActivityThread.java:7725)
  at java.lang.reflect.Method.invoke(Native method)
  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:526)
  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1034)
   
  ........省略N行.....
   
  "WQW TEST" prio=5 tid=3 TimeWating
  | group="main" sCount=1 dsCount=0 flags=1 obj=0x12c44230 self=0x772f0ec000
  | sysTid=22938 nice=0 cgrp=default sched=0/0 handle=0x77391fbd50
  | state=S schedstat=( 274896 0 1 ) utm=0 stm=0 core=1 HZ=100
  | stack=0x77390f9000-0x77390fb000 stackSize=1039KB
  | held mutexes=
  at java.lang.Thread.sleep(Native method)
  - sleeping on <0x043831a6> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:440)
  - locked <0x043831a6> (a java.lang.Object)
  at java.lang.Thread.sleep(Thread.java:356)
  at xxx.xx.MainActivity$onCreate$2$thread$1.run(MainActivity.kt:22)
  - locked <0x01aed1da> (a java.lang.Object)————————————————————关键行！！！
  at java.lang.Thread.run(Thread.java:919)

```

主线程Blocked状态，waiting to lock <0x01aed1da> (a java.lang.Object) held by thread 3 表明主线程正在等待锁<0x01aed1da>，该锁被3#线程持有。锁阻塞的情况需要分清是死锁还是锁竞争；

### 5.4 CPU被抢占
```
CPU usage from 0ms to 10625ms later (2020-03-09 14:38:31.633 to 2020-03-09 14:38:42.257):
  543% 2045/com.alibaba.android.rimet: 54% user + 89% kernel / faults: 4608 minor 1 major ————关键行！！！
  99% 674/android.hardware.camera.provider@2.4-service: 81% user + 18% kernel / faults: 403 minor
  24% 32589/com.wang.test: 22% user + 1.4% kernel / faults: 7432 minor 1 major
  ........省略N行.....
```
如上日志，第二行是钉钉的进程，占据CPU高达543%，抢占了大部分CPU资源，因而导致发生ANR。

### 5.5 内存紧张导致ANR
如果有一份日志，CPU和堆栈都很正常（不贴出来了），仍旧发生ANR，考虑是内存紧张。

从CPU第一行信息可以发现，ANR的时间点是2020-10-31 22:38:58.468—CPU usage from 0ms to 21752ms later (2020-10-31 22:38:58.468 to 2020-10-31 22:39:20.220)

接着去系统日志里搜索am_meminfo， 这个没有搜索到。再次搜索onTrimMemory，果然发现了很多条记录；

```
java
 体验AI代码助手
 代码解读
复制代码
10-31 22:37:19.749 20733 20733 E Runtime : onTrimMemory level:80,pid:com.xxx.xxx:Launcher0
10-31 22:37:33.458 20733 20733 E Runtime : onTrimMemory level:80,pid:com.xxx.xxx:Launcher0
10-31 22:38:00.153 20733 20733 E Runtime : onTrimMemory level:80,pid:com.xxx.xxx:Launcher0
10-31 22:38:58.731 20733 20733 E Runtime : onTrimMemory level:80,pid:com.xxx.xxx:Launcher0
10-31 22:39:02.816 20733 20733 E Runtime : onTrimMemory level:80,pid:com.xxx.xxx:Launcher0
```

可以看出，在发生ANR的时间点前后，内存都处于紧张状态，level等级是80，查看Android API 文档；

```
java
 体验AI代码助手
 代码解读
复制代码
   /**
    * Level for {@link #onTrimMemory(int)}: the process is nearing the end
    * of the background LRU list, and if more memory isn't found soon it will
    * be killed.
    */
   static final int TRIM_MEMORY_COMPLETE = 80;
```

可知80这个等级是很严重的，应用马上就要被杀死，被杀死的这个应用从名字可以看出来是桌面，连桌面都快要被杀死，那普通应用能好到哪里去呢？

一般来说，发生内存紧张，会导致多个应用发生ANR，所以在日志中如果发现有多个应用一起ANR了，可以初步判定，此ANR与你的应用无关。

## 5.6 系统服务超时导致ANR
```
"main" prio=5 tid=1 Native
  | group="main" sCount=1 dsCount=0 flags=1 obj=0x727851e8 self=0x78d7060e00
  | sysTid=4894 nice=0 cgrp=default sched=0/0 handle=0x795cc1e9a8
  | state=S schedstat=( 8292806752 1621087524 7167 ) utm=707 stm=122 core=5 HZ=100
  | stack=0x7febb64000-0x7febb66000 stackSize=8MB
  | held mutexes=
  kernel: __switch_to+0x90/0xc4
  kernel: binder_thread_read+0xbd8/0x144c
  kernel: binder_ioctl_write_read.constprop.58+0x20c/0x348
  kernel: binder_ioctl+0x5d4/0x88c
  kernel: do_vfs_ioctl+0xb8/0xb1c
  kernel: SyS_ioctl+0x84/0x98
  kernel: cpu_switch_to+0x34c/0x22c0
  native: #00 pc 000000000007a2ac  /system/lib64/libc.so (__ioctl+4)
  native: #01 pc 00000000000276ec  /system/lib64/libc.so (ioctl+132)
  native: #02 pc 00000000000557d4  /system/lib64/libbinder.so (android::IPCThreadState::talkWithDriver(bool)+252)
  native: #03 pc 0000000000056494  /system/lib64/libbinder.so (android::IPCThreadState::waitForResponse(android::Parcel*, int*)+60)
  native: #04 pc 00000000000562d0  /system/lib64/libbinder.so (android::IPCThreadState::transact(int, unsigned int, android::Parcel const&, android::Parcel*, unsigned int)+216)
  native: #05 pc 000000000004ce1c  /system/lib64/libbinder.so (android::BpBinder::transact(unsigned int, android::Parcel const&, android::Parcel*, unsigned int)+72)
  native: #06 pc 00000000001281c8  /system/lib64/libandroid_runtime.so (???)
  native: #07 pc 0000000000947ed4  /system/framework/arm64/boot-framework.oat (Java_android_os_BinderProxy_transactNative__ILandroid_os_Parcel_2Landroid_os_Parcel_2I+196)
  at android.os.BinderProxy.transactNative(Native method) ————————————————关键行！！！
  at android.os.BinderProxy.transact(Binder.java:804)
  at android.net.IConnectivityManager$Stub$Proxy.getActiveNetworkInfo(IConnectivityManager.java:1204)—关键行！
  at android.net.ConnectivityManager.getActiveNetworkInfo(ConnectivityManager.java:800)
  at com.xiaomi.NetworkUtils.getNetworkInfo(NetworkUtils.java:2)
  at com.xiaomi.frameworkbase.utils.NetworkUtils.getNetWorkType(NetworkUtils.java:1)
  at com.xiaomi.frameworkbase.utils.NetworkUtils.isWifiConnected(NetworkUtils.java:1)

```

从堆栈可以看出获取网络信息发生了ANR：getActiveNetworkInfo。

前文有讲过：系统的服务都是Binder机制（16个线程），服务能力也是有限的，有可能系统服务长时间不响应导致ANR。如果其他应用占用了所有Binder线程，那么当前应用只能等待。

可进一步搜索：blockUntilThreadAvailable关键字：
`at android.os.Binder.blockUntilThreadAvailable(Native method)`
如果有发现某个线程的堆栈，包含此字样，可进一步看其堆栈，确定是调用了什么系统服务。此类ANR也是属于系统环境的问题，如果某类型机器上频繁发生此问题，应用层可以考虑规避策略。

其他一些日志中可能的概念：

RssHwmKb: 102932：这是进程的"高水位"（High Water Mark）驻留集大小（Resident Set Size，RSS），以KB为单位。这是进程在其生命周期中一次所使用的最大物理内存量。
RssKb: 102932：这是进程当前的驻留集大小（Resident Set Size，RSS），以KB为单位。这是进程当前正在使用的物理内存量。
RssAnonKb: 37956：这是进程的匿名驻留集大小，以KB为单位。这是进程使用的不与任何文件关联的物理内存量，通常包括堆和栈空间。
RssShmemKb: 640：这是进程的共享内存驻留集大小，以KB为单位。这是进程使用的与其他进程共享的物理内存量。
VmSwapKb: 22452：这是进程的虚拟内存交换空间使用量，以KB为单位。这是进程的虚拟内存被交换出到交换空间（swap space）的量。
这些信息可以帮助我们理解进程的内存使用情况，以及可能的内存问题。例如，如果RssHwmKb远大于RssKb，那么可能意味着进程在某些时候使用了大量的内存，但现在已经释放了这些内存。如果VmSwapKb很大，那么可能意味着进程的内存使用量超过了物理内存的容量，导致大量的内存被交换出到交换空间，这可能会导致性能问题。

## 6.总结
- 实际过程中发生的ANR问题，并不会像案例那样直白明了的看出问题；
- 存在捕获ANR日志时已经错过了最佳时机，导致获取的堆栈信息没什么价值；
- Activity生命周期超时会不会ANR？——经测试并不会。 -- 来源于网络
- 如果应用侧消除了慢函数以及解决了严苛模式问题，那么大部分的ANR问题可能与系统负载有关；